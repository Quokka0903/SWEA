A = input().split(', ')
if (len(A[0]) > len(A[1])) :
    print (A[0])
else :
    print (A[1])