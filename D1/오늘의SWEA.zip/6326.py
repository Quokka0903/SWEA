a = int(input())
fac = 1
for i in range(1, a + 1) :
    fac *= i
print(fac)